//
// OCI telemetry format
//

// dates are set like this
var sdf = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
var tz = java.util.TimeZone.getTimeZone("UTC");
sdf.setTimeZone(tz);

////////////////////////////////////////////////////////////////
// function: dataTransformExpansion
//   Properties srcDesc: details about the source
//   Properties snkDest: details about the destination
// returns float: a factor (> 1.0) which represents the markup
//                expansion
//
// Compute a factor which is the ratio of marked-up data size :
// raw data size
////////////////////////////////////////////////////////////////
function dataTransformExpansion(srcDesc, snkDesc)
{
  return 5.0;
}

////////////////////////////////////////////////////////////////
// function: transformData
//   Properties srcDesc: details about the source
//   Properties snkDest: details about the destination
//   MetricObservation dataSet: the data
// returns JsonPayload: a payload in json format
//
// Produce the json for the data set.
////////////////////////////////////////////////////////////////
function transformData(srcDesc, snkDesc, dataSet)
{
  var compartmentId = srcDesc.get("compartmentId");
  var namespace = snkDesc.get("namespace");
  var hostname = snkDesc.get("agentHostName");
  var agentId = snkDesc.get("agentId");

  var payload = "{ \"metricData\": [ ";
  var first = true;
  var rn;
  var cn;
  var mn = dataSet.getRelationName();
  var KEY_NAMES = dataSet.getKeyNames();
  for (rn = 0; rn < dataSet.getRowCount(); rn++)
  {
    for (cn = 0; cn < dataSet.getColumnCount(); cn++)
    {
      if (!first)
      {
        payload += ", ";
      }
      else
      {
        first = false;
      }

      var drow = dataSet.getRow(rn);
      var dcol = dataSet.getColumn(cn);
      var dcolMetadata = dcol.getColumnMetadata();
      var colName = dcol.getColumnName();
      var displayMetricName = mn + colName.charAt(0).toUpperCase() + colName.substring(1); 

      // TEL-13655: resourceId is special and must match the agent OCID if using Resource Principals for authentication
      payload += "{ \"namespace\": \"" + namespace + "\", \"compartmentId\": \"" + compartmentId + "\", \"name\": \"" + displayMetricName + "\", \"dimensions\": { \"agentHostName\": \"" + hostname + "\", \"resourceId\": \"" + agentId + "\" ";
      var kn;
      for (kn = 0; kn < KEY_NAMES.length; kn++)
      {
	    var keyName = KEY_NAMES[kn];
        var displayKeyName = mn + keyName.charAt(0).toUpperCase() + keyName.substring(1);
        payload += ", \"" + displayKeyName + "\": \"" + jsonEncodeNonNull(drow.getKey()[kn]) + "\"";
      }
      payload += " },";

      if (dcolMetadata != null && !dcolMetadata.isEmpty())
      {
        // render the metadata, as "metadata":{n:v,...},
        payload += "\"metadata\":{";
        var first = true;
        var entries = dcolMetadata.entrySet().iterator();
        while (entries.hasNext())
        {
          if (first)
          {
            first = false;
          }
          else
          {
            payload += ",";
          }
          var entry = entries.next();
          payload += "\"" + entry.getKey() + "\":\"" + jsonEncodeNonNull(entry.getValue()) + "\"";
        }
        payload += "},";
      }
      payload += "\"datapoints\": [ { \"timestamp\": \"" + sdf.format(drow.getTimestamp()) + "\", \"value\": ";
      // ociservicevalidator has asserted these are only numeric
      payload += dataSet.getCell(rn, cn).getValue();
      payload += ", \"count\": 1 } ] }";
    }
    
    // compact payload every 10 rows
    if(rn % 10 == 0){
    	payload = payload.toString();
    }
  }

  payload += " ] }";
  payload = payload.toString();
  var output = new JsonPayload(payload);
  return output;
}
