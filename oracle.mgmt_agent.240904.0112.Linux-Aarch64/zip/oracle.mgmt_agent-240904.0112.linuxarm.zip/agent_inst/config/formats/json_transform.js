//
// Formatter Utilities
//

var JsonPayload = Java.type('oracle.polaris.core.services.data.outflow.JsonPayload');
var StringPayload = Java.type('oracle.polaris.core.services.data.outflow.StringPayload');

var FormatterUtils =
  Java.type("oracle.polaris.core.services.data.outflow.FormatterUtils");

////////////////////////////////////////////////////////////////
// function: jsonEncodeNonNull
//   String value: the raw string to encode (not null)
// returns String: a basic encoding of the value
//
// Do JSON encoding.
////////////////////////////////////////////////////////////////
function jsonEncodeNonNull(value)
{
  return FormatterUtils.encode(value, "application/json");
}

////////////////////////////////////////////////////////////////
// function: getLogTag
//   Properties properties: the (sink) properties containing log tags
//   String tag: the tag's name
// returns String: the tag's value (null if not found)
//
// Look up a logTag as specified in the work item that triggered the query
// result formatting.
////////////////////////////////////////////////////////////////
function getLogTag(properties, tag)
{
  return FormatterUtils.getLogTag(properties, tag);
}

////////////////////////////////////////////////////////////////
//function: getFormattersDir
//  Properties srcDest: the properties containing the source destination info
//returns String: the formatters root dir if found (null if not found)
// notes: the 'formatter root' where java script is likely to be stored. 
//
////////////////////////////////////////////////////////////////
function getFormattersDir(srcDest)
{
	return FormatterUtils.getFormattersDir(srcDest);
}

////////////////////////////////////////////////////////////////
//function: getLogger
// 
//returns a logger that implements oracle.polaris.core.data.outflow.impl.TransformerLogger
//
////////////////////////////////////////////////////////////////
function getLogger()
{
    return FormatterUtils.getLogger();
}

